<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Category;
use App\Question;

class QuestionController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function getByCategory($categoryid)
    {
        return Question::where('category',$categoryid)->take(10)->get();
    }

    public function getBySubCategory($subcatid,$level)
    {
        return Question::where('subcategory',$subcatid)->where('level',$level)->take(10)->get();
    }

    public function store(Request $request)
    {
        return Question::create($request->all());
    }
}
